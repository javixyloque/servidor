<?php
// JAVIER ALVAREZ CENTENO
$tipo = ['libro', 'transporte', 'vivienda'];

function calcularImporteBeca() {

}