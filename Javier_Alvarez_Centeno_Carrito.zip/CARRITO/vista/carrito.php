<?php
    session_start();
    require_once'../controlador/controlador.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CARRITO</title>
</head>
<body>
    <?php
        pintarCarrito();
        
    ?>
    
</body>
</html>    