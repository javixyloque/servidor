"use strict"; 


window.addEventListener("DOMContentLoaded", ()=> {

    const body = document.querySelector("body");   
    const principal = document.querySelector("main");
});