<?php

    require_once'./src/Entity/Equipo.php';
    require_once'./src/Entity/Jugador.php';
    require_once'./src/Entity/Partido.php';


    




?>