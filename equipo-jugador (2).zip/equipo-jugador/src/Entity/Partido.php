<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * Partido
 *
 * @ORM\Table(name="partido", indexes={@ORM\Index(name="visitante", columns={"visitante"}), @ORM\Index(name="local", columns={"local"})})
 * @ORM\Entity
 */
class Partido
{
    /**
     * @var int
     *
     * @ORM\Column(name="id_partido", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idPartido;

    /**
     * @var int
     *
     * @ORM\Column(name="goles_local", type="integer", nullable=false)
     */
    private $golesLocal;

    /**
     * @var int
     *
     * @ORM\Column(name="goles_visitante", type="integer", nullable=false)
     */
    private $golesVisitante;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fecha", type="date", nullable=false)
     */
    private $fecha;

    /**
     * @var \Equipo
     *
     * @ORM\ManyToOne(targetEntity="Equipo")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="local", referencedColumnName="id_equipo")
     * })
     */
    private $local;

    /**
     * @var \Equipo
     *
     * @ORM\ManyToOne(targetEntity="Equipo")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="visitante", referencedColumnName="id_equipo")
     * })
     */
    private $visitante;


}
